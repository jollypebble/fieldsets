/* eslint-disable */
const Auth = {
  google: {
    web: {
      client_id: "190543481472-4ecdtge3tdg6td89goq0tbumgrm66s3g.apps.googleusercontent.com",
      project_id:"econ-circles",
      auth_uri:"https://accounts.google.com/o/oauth2/auth",
      token_uri:"https://accounts.google.com/o/oauth2/token",
      auth_provider_x509_cert_url:"https://www.googleapis.com/oauth2/v1/certs",
      client_secret:"si_vzVyP5rJg-1OA36a5f68z",
      redirect_uris:["https://econcircles.com/oauth2callback"],
      javascript_origins:["https://econcircles.com","http://localhost:3000"]
    }
  }
};
export default Auth;
