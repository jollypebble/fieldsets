export default {
  sheetName: 'EconSystem Diagram',
  sheetID: '1a2mF1db5smYpsrPMa9Qnz1C_OMdqEa3eJvqQ6zTh7vU',
  apiKey: 'AIzaSyA8oV-lWxbRLavCokyIKqPWC4nwzJbXYAE'
};
